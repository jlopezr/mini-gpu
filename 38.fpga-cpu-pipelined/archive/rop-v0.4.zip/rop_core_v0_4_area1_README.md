# MiniGPU ROP v0.4-area1 — first area optimization experiment

Source: `rop_core_v0_4_area1.v` (top module still `rop_core`).

Changes limited to SPAN and FRAGMENT:
- Replaces combinational `for (t=0; t<4; ...)` with `S_SP_PIXEL` (one pixel per clock).
- One shared Z comparator (16/32 bits, signed/unsigned, modes ALWAYS/EQ/NE/LT/LE/GT/GE).
- Uses `read_buffer`, already captured on `read_response`, to retain the complete 128-bit old-Z word.
- Accumulates 128-bit output words and byte masks sequentially.
- Keeps `S_SP_SYNC` RMW barrier and the original address/row/fragment advancement.
- No changes intended for FILL, COPY, GENERATE2D or CONFIG.

**Status:** HDL simulation and ECP5 synthesis could not run in this environment (iverilog/vvp/Yosys not installed). A separate software-level randomized comparison of the old/new per-group computation passed 100,000 cases; this is **not** a substitute for RTL simulation.

On Mac with Apio:

```sh
~/.apio/packages/oss-cad-suite/bin/iverilog -g2012 -s rop_core_tb \
  -o /tmp/rop_area1.out rop_core_v0_4_area1.v rop_core_v0_4_tb.sv \
  && ~/.apio/packages/oss-cad-suite/bin/vvp /tmp/rop_area1.out

~/.apio/packages/oss-cad-suite/bin/yosys -p \
  'read_verilog -sv rop_core_v0_4_area1.v; hierarchy -check -top rop_core; synth_ecp5 -top rop_core; stat' \
  > rop_area1_synth.log 2>&1
tail -45 rop_area1_synth.log
```

Baseline v0.4: LUT4 9581, TRELLIS_FF 2289, CCU2C 743, PFUMX 1908, L6MUX21 265, MULT18X18D 2.

Note: variable dynamic part-select writes to 128-bit registers can themselves cost a lot of LUTs/muxes. Evaluate the new synthesis before assuming area savings. Also consider a more thorough testbench for response errors and backpressure.
