`default_nettype none
// MiniGPU ROP core, prototype v0.4: ordered persistent CONFIG + compact SPAN/FRAGMENT.
// One active command, multiple outstanding writes, one in-flight read.
// In-order responses are REQUIRED (as in dma_engine_v2).
// FILL/COPY/GEN keep v0.1 alignment rules. SPAN/FRAGMENT support partial words.
module rop_core #(
    parameter integer TAG_DEPTH = 8
)(
    input wire clk,
    input wire reset,
    input wire cmd_valid,
    output wire cmd_ready,
    input wire [2:0] cmd_op,       // 0 FILL, 1 COPY, 2 GENERATE2D, 3 SPAN, 4 FRAGMENT, 5 CONFIG
    input wire [12:0] cmd_mode,    // meaning depends on cmd_op (see README)
    input wire [319:0] cmd_params, // p0 = bits 31:0, ..., p9 = 319:288
    input wire [255:0] cmd_frag_colors, // lane i color at [32*i +: 32]
    input wire [255:0] cmd_frag_z,      // lane i Z at [32*i +: 32]
    output reg done_valid,         // single-cycle completion pulse
    output reg done_error,         // meaningful when done_valid
    output wire busy,
    output wire req_valid,
    input wire req_ready,
    output wire req_write,
    output wire [31:0] req_addr,
    output wire [127:0] req_wdata,
    output wire [15:0] req_wmask,
    input wire rsp_valid,
    output wire rsp_ready,
    input wire [127:0] rsp_rdata,
    input wire rsp_error
);
    localparam [2:0] OP_FILL=3'd0, OP_COPY=3'd1, OP_GEN=3'd2, OP_SPAN=3'd3, OP_FRAGMENT=3'd4, OP_CONFIG=3'd5;
    localparam [3:0] S_IDLE=0, S_PREP=1, S_READ_REQ=2,
       S_READ_WAIT=3, S_WRITE_REQ=4, S_ADV=5, S_DRAIN=6,
       S_SP_PREP=7, S_SP_READ_REQ=8, S_SP_READ_WAIT=9,
       S_SP_Z_REQ=10, S_SP_COLOR_REQ=11, S_SP_ADV=12,
       S_SP_SYNC=13;
    localparam integer PTR_W = (TAG_DEPTH <= 2) ? 1 : $clog2(TAG_DEPTH);
    // Ordered persistent configuration. No MMIO; CONFIG is another command.
    // CONFIG mode[4:0] selects fields to update (see README v0.4).
    reg [31:0] cfg_color_base, cfg_z_base;
    reg [31:0] cfg_color_stride, cfg_z_stride;
    reg [31:0] cfg_color, cfg_z0, cfg_dx, cfg_dy;
    reg [7:0] cfg_render_mode;
    reg [4:0] cfg_written;
    reg [3:0] state;
    reg [2:0] op;
    reg [12:0] mode;
    reg [31:0] row_src, row_dst, cur_src, cur_dst;
    reg [31:0] rows_left, blocks_left, blocks_per_row;
    reg [31:0] src_stride, dst_stride, pattern, dx, dy;
    reg [31:0] row_z, cur_z;
    // SPAN owns explicit independent color/depth pointers and strides.
    reg [31:0] sp_color_row, sp_z_row, sp_color_cur, sp_z_cur;
    reg [31:0] sp_color_stride, sp_z_stride;
    reg [31:0] sp_width, sp_remaining, sp_rows, sp_row_initial, sp_cur_z;
    reg [31:0] sp_dx, sp_dy, sp_color;
    reg [2:0] sp_step;
    reg [3:0] frag_index;   // index of first fragment in current group (0..7)
    reg [7:0] frag_coverage;
    reg [255:0] frag_colors, frag_depths;
    reg [127:0] sp_z_data, sp_color_data;
    reg [15:0] sp_z_mask, sp_color_mask;
    reg [127:0] read_buffer;
    reg [127:0] generated;
    reg [15:0] write_mask;
    reg failed;
    reg [PTR_W-1:0] tag_wr, tag_rd;
    reg [PTR_W:0] tag_count;
    reg tag_is_read [0:TAG_DEPTH-1];
    wire tags_full = (tag_count == TAG_DEPTH);
    wire tags_empty = (tag_count == 0);
    wire [31:0] p0=cmd_params[31:0];
    wire [31:0] p1=cmd_params[63:32];
    wire [31:0] p2=cmd_params[95:64];
    wire [31:0] p3=cmd_params[127:96];
    wire [31:0] p4=cmd_params[159:128];
    wire [31:0] p5=cmd_params[191:160];
    wire [31:0] p6=cmd_params[223:192];
    wire [31:0] p7=cmd_params[255:224];
    wire [31:0] p8=cmd_params[287:256];
    wire [31:0] p9=cmd_params[319:288];
    wire compact_graphics = cmd_mode[12];
    wire [31:0] compact_color_address = cfg_color_base + p0;
    wire [31:0] compact_z_address = cfg_z_base + p1;
    // Compact SPAN overrides: bit 8 color, bit 9 initial Z,
    // bit 10 dX, bit 11 dY. FRAGMENT must not set overrides.
    wire [31:0] effective_color = cmd_mode[8] ? p4 : cfg_color;
    wire [31:0] effective_z0 = cmd_mode[9] ? p5 : cfg_z0;
    wire [31:0] effective_dx = cmd_mode[10] ? p6 : cfg_dx;
    wire [31:0] effective_dy = cmd_mode[11] ? p7 : cfg_dy;
    wire width32 = mode[3];
    wire sp_color32 = mode[3];
    wire sp_z32 = mode[4];
    wire sp_write_z = mode[5];
    wire sp_write_color = mode[6];
    wire sp_signed = mode[7];
    wire [2:0] sp_cmp = mode[2:0];
    wire [31:0] sp_z_offset = {28'd0, sp_z_cur[3:0]};
    wire [31:0] sp_color_offset = {28'd0, sp_color_cur[3:0]};
    wire [31:0] sp_z_room = (32'd16 - sp_z_offset) >> (sp_z32 ? 2 : 1);
    wire [31:0] sp_color_room = (32'd16 - sp_color_offset) >> (sp_color32 ? 2 : 1);
    wire [31:0] sp_step_w = (sp_remaining < 32'd4 ? sp_remaining : 32'd4) < sp_z_room ?
        (sp_remaining < 32'd4 ? sp_remaining : 32'd4) : sp_z_room;
    wire [31:0] sp_step_calc = sp_step_w < sp_color_room ? sp_step_w : sp_color_room;
    wire [31:0] value_step = width32 ? (dx << 2) : (dx << 3);
    wire response = rsp_valid && rsp_ready;
    
    // We need no read for unconditional FILL and GENERATE2D.
    wire needs_read = (op == OP_COPY) ||
                      ((op == OP_GEN) && (mode[2:0] != 3'd0));
    assign cmd_ready = (state == S_IDLE) && !reset;
    assign busy = (state != S_IDLE);
    assign req_valid = !reset && !tags_full && !(response && rsp_error) &&
                       (state == S_READ_REQ ||
                       (state == S_WRITE_REQ && write_mask != 16'h0000) ||
                       state == S_SP_READ_REQ ||
                       (state == S_SP_Z_REQ && sp_z_mask != 0) ||
                       (state == S_SP_COLOR_REQ && sp_color_mask != 0));
    assign req_write = (state == S_WRITE_REQ || state == S_SP_Z_REQ ||
                        state == S_SP_COLOR_REQ);
    assign req_addr = (state == S_SP_READ_REQ || state == S_SP_Z_REQ) ?
                          {sp_z_cur[31:4], 4'b0} :
                      (state == S_SP_COLOR_REQ) ?
                          {sp_color_cur[31:4], 4'b0} :
                      (state == S_READ_REQ) ?
                          ((op == OP_COPY) ? cur_src : cur_dst) : cur_dst;
    assign req_wdata = (state == S_SP_Z_REQ) ? sp_z_data :
                       (state == S_SP_COLOR_REQ) ? sp_color_data :
                       (op == OP_FILL) ? {4{pattern}} :
                       ((op == OP_COPY) ? read_buffer : generated);
    assign req_wmask = (state == S_SP_Z_REQ) ? sp_z_mask :
                       (state == S_SP_COLOR_REQ) ? sp_color_mask :
                       (state == S_WRITE_REQ) ? write_mask : 16'h0000;
    wire issue = req_valid && req_ready;
    assign rsp_ready = !reset && !tags_empty;    
    wire read_response = response && tag_is_read[tag_rd];
    wire [2:0] cmp = mode[2:0];
    wire signed_cmp = mode[4];

    // Parallel candidate generation. May be replaced by a multicycle generator
    // if the timing/area results suggest sharing the adder.
    reg [127:0] gen_word;
    reg [15:0] cmp_mask;
    reg [31:0] v;
    reg passed;
    reg [31:0] new_value, old_value;
    integer k;
    always @* begin
        gen_word = 128'd0;
        cmp_mask = 16'd0;
        v = cur_z;
        passed = 1'b0;
        new_value = 32'd0;
        old_value = 32'd0;
        for (k=0; k<8; k=k+1) begin
            if ((width32 && k<4) || !width32) begin
                if (width32) begin
                    new_value = v;
                    old_value = rsp_rdata[k*32 +: 32];
                    gen_word[k*32 +: 32] = v;
                end else begin
                    new_value = {16'd0,v[15:0]};
                    old_value = {16'd0,rsp_rdata[k*16 +: 16]};
                    gen_word[k*16 +: 16] = v[15:0];
                end
                case (cmp)
                    3'd0: passed = 1'b1;
                    3'd1: passed = (new_value == old_value);
                    3'd2: passed = (new_value != old_value);
                    3'd3: passed = signed_cmp ?
                        (width32 ? ($signed(new_value) < $signed(old_value)) :
                                   ($signed(new_value[15:0]) < $signed(old_value[15:0]))) :
                        (new_value < old_value);
                    3'd4: passed = signed_cmp ?
                        (width32 ? ($signed(new_value) <= $signed(old_value)) :
                                   ($signed(new_value[15:0]) <= $signed(old_value[15:0]))) :
                        (new_value <= old_value);
                    3'd5: passed = signed_cmp ?
                        (width32 ? ($signed(new_value) > $signed(old_value)) :
                                   ($signed(new_value[15:0]) > $signed(old_value[15:0]))) :
                        (new_value > old_value);
                    3'd6: passed = signed_cmp ?
                        (width32 ? ($signed(new_value) >= $signed(old_value)) :
                                   ($signed(new_value[15:0]) >= $signed(old_value[15:0]))) :
                        (new_value >= old_value);
                    default: passed = 1'b0;
                endcase
                if (passed) begin
                    if (width32) cmp_mask[k*4 +: 4] = 4'hf;
                    else cmp_mask[k*2 +: 2] = 2'b11;
                end
                v = v + dx;
            end
        end
    end

    // SPAN group: 1..4 consecutive pixels, truncated at *both* 128-bit
    // memory word boundaries. The physical byte positions in color and Z
    // are independent. Z is modular 32-bit; Z16 keeps low 16 bits.
    reg [127:0] sp_gen_z_word, sp_gen_color_word;
    reg [15:0] sp_gen_z_mask, sp_gen_color_mask;
    reg [31:0] sp_old, sp_new, sp_v;
    reg sp_pass;
    integer t, zbit, cbit;
    always @* begin
        sp_gen_z_word = 128'd0;
        sp_gen_color_word = 128'd0;
        sp_gen_z_mask = 16'd0;
        sp_gen_color_mask = 16'd0;
        sp_old = 0;
        sp_new = 0;
        sp_pass = 0;
        sp_v = sp_cur_z;
        zbit = 0;
        cbit = 0;
        for (t=0;t<4;t=t+1) begin
            if (t < sp_step) begin
                zbit = (sp_z_cur[3:0] + t*(sp_z32 ? 4 : 2))*8;
                cbit = (sp_color_cur[3:0] + t*(sp_color32 ? 4 : 2))*8;
                if (op == OP_FRAGMENT)
                    sp_v = (frag_depths >> (32*(frag_index+t))) & 32'hffffffff;
                if (sp_z32) begin
                    sp_new = sp_v;
                    sp_old = (rsp_rdata >> zbit) & 32'hffffffff;
                    sp_gen_z_word = sp_gen_z_word |
                        ({96'd0,sp_v} << zbit);
                end else begin
                    sp_new = {16'd0,sp_v[15:0]};
                    sp_old = (rsp_rdata >> zbit) & 32'h0000ffff;
                    sp_gen_z_word = sp_gen_z_word |
                        ({112'd0,sp_v[15:0]} << zbit);
                end
                case (sp_cmp)
                    3'd0: sp_pass = 1'b1;
                    3'd1: sp_pass = (sp_new == sp_old);
                    3'd2: sp_pass = (sp_new != sp_old);
                    3'd3: sp_pass = sp_signed ?
                        (sp_z32 ? ($signed(sp_new) < $signed(sp_old)) :
                                  ($signed(sp_new[15:0]) < $signed(sp_old[15:0]))) :
                        (sp_new < sp_old);
                    3'd4: sp_pass = sp_signed ?
                        (sp_z32 ? ($signed(sp_new) <= $signed(sp_old)) :
                                  ($signed(sp_new[15:0]) <= $signed(sp_old[15:0]))) :
                        (sp_new <= sp_old);
                    3'd5: sp_pass = sp_signed ?
                        (sp_z32 ? ($signed(sp_new) > $signed(sp_old)) :
                                  ($signed(sp_new[15:0]) > $signed(sp_old[15:0]))) :
                        (sp_new > sp_old);
                    3'd6: sp_pass = sp_signed ?
                        (sp_z32 ? ($signed(sp_new) >= $signed(sp_old)) :
                                  ($signed(sp_new[15:0]) >= $signed(sp_old[15:0]))) :
                        (sp_new >= sp_old);
                    default: sp_pass = 1'b0;
                endcase
                // Coverage is an independent predicate, applied after Z-test.
                // The index refers to screen order, including inactive lanes.
                if (op == OP_FRAGMENT && !frag_coverage[frag_index+t])
                    sp_pass = 1'b0;
                if (sp_pass) begin
                    if (sp_write_z) begin
                        if (sp_z32) sp_gen_z_mask[(zbit/8) +: 4] = 4'hf;
                        else sp_gen_z_mask[(zbit/8) +: 2] = 2'b11;
                    end
                    if (sp_write_color) begin
                        if (sp_color32) begin
                            sp_gen_color_mask[(cbit/8) +: 4] = 4'hf;
                            sp_gen_color_word = sp_gen_color_word |
                                ({96'd0,((op == OP_FRAGMENT) ?
                                  ((frag_colors >> (32*(frag_index+t))) & 32'hffffffff) : sp_color)} << cbit);
                        end else begin
                            sp_gen_color_mask[(cbit/8) +: 2] = 2'b11;
                            sp_gen_color_word = sp_gen_color_word |
                                ({112'd0,((op == OP_FRAGMENT) ?
                                  ((frag_colors >> (32*(frag_index+t))) & 32'hffff) : {16'd0,sp_color[15:0]})} << cbit);
                        end
                    end
                end
                if (op != OP_FRAGMENT) sp_v = sp_v + sp_dx;
            end
        end
    end

    // Pointers do not need power-of-two depth (only TAG_DEPTH >=2).
    wire [PTR_W-1:0] wr_next = (tag_wr == TAG_DEPTH-1) ? 0 : tag_wr + 1'b1;
    wire [PTR_W-1:0] rd_next = (tag_rd == TAG_DEPTH-1) ? 0 : tag_rd + 1'b1;
    reg valid_command;
    always @* begin
        valid_command = 1'b0;
        case (cmd_op)
            OP_FILL: valid_command = p1 != 0 && p2 != 0 &&
                p0[3:0] == 0 && p1[3:0] == 0 && p3[3:0] == 0;
            OP_COPY: valid_command = p2 != 0 && p3 != 0 &&
                p0[3:0] == 0 && p1[3:0] == 0 && p2[3:0] == 0 &&
                p4[3:0] == 0 && p5[3:0] == 0;
            OP_GEN: valid_command = p1 != 0 && p2 != 0 &&
                p0[3:0] == 0 && p3[3:0] == 0 &&
                (cmd_mode[3] ? (p1[1:0] == 0) : (p1[2:0] == 0)) &&
                cmd_mode[2:0] != 3'd7 && cmd_mode[12:5] == 0;
            OP_SPAN: begin
                if (!compact_graphics) begin
                    valid_command = p2 != 0 && p3 != 0 &&
                        cmd_mode[2:0] != 3'd7 && cmd_mode[12:8] == 0 &&
                        (cmd_mode[5] || cmd_mode[6]) &&
                        p0[0] == 0 && p1[0] == 0 &&
                        (!cmd_mode[3] || (p0[1:0] == 0 && p4[1:0] == 0)) &&
                        (!cmd_mode[4] || (p1[1:0] == 0 && p5[1:0] == 0)) &&
                        (cmd_mode[3] || !p4[0]) &&
                        (cmd_mode[4] || !p5[0]);
                end else begin
                    valid_command = (cfg_written == 5'b11111) &&
                        p2 != 0 && p3 != 0 && cmd_mode[7:0] == 0 &&
                        p8 == 0 && p9 == 0 &&
                        cfg_render_mode[2:0] != 3'd7 &&
                        (cfg_render_mode[5] || cfg_render_mode[6]) &&
                        compact_color_address[0] == 0 && compact_z_address[0] == 0 &&
                        (!cfg_render_mode[3] || (compact_color_address[1:0] == 0 && cfg_color_stride[1:0] == 0)) &&
                        (!cfg_render_mode[4] || (compact_z_address[1:0] == 0 && cfg_z_stride[1:0] == 0)) &&
                        (cfg_render_mode[3] || !cfg_color_stride[0]) &&
                        (cfg_render_mode[4] || !cfg_z_stride[0]);
                end
            end
            OP_FRAGMENT: begin
                if (!compact_graphics) begin
                    valid_command = p2 >= 1 && p2 <= 8 &&
                        cmd_mode[2:0] != 3'd7 && cmd_mode[12:8] == 0 &&
                        (cmd_mode[5] || cmd_mode[6]) &&
                        p0[0] == 0 && p1[0] == 0 &&
                        (!cmd_mode[3] || p0[1:0] == 0) &&
                        (!cmd_mode[4] || p1[1:0] == 0) &&
                        p3[31:8] == 0 && (p3[7:0] >> p2) == 0 &&
                        p4 == 0 && p5 == 0 && p6 == 0 && p7 == 0 &&
                        p8 == 0 && p9 == 0;
                end else begin
                    valid_command = cfg_written[4:0] == 5'b11111 &&
                        cmd_mode[11:0] == 0 && p2 >= 1 && p2 <= 8 &&
                        cfg_render_mode[2:0] != 3'd7 &&
                        (cfg_render_mode[5] || cfg_render_mode[6]) &&
                        compact_color_address[0] == 0 && compact_z_address[0] == 0 &&
                        (!cfg_render_mode[3] || compact_color_address[1:0] == 0) &&
                        (!cfg_render_mode[4] || compact_z_address[1:0] == 0) &&
                        p3[31:8] == 0 && (p3[7:0] >> p2) == 0 &&
                        p4 == 0 && p5 == 0 && p6 == 0 && p7 == 0 &&
                        p8 == 0 && p9 == 0;
                end
            end
            OP_CONFIG: valid_command = cmd_mode[12:5] == 0 &&
                cmd_mode[4:0] != 0 &&
                p9 == 0 &&
                (!cmd_mode[4] || (p8[31:8] == 0 && p8[2:0] != 3'd7 &&
                    (p8[5] || p8[6])));
            default: valid_command = 1'b0;
        endcase
    end

    always @(posedge clk) begin
        if (reset) begin
            state <= S_IDLE;
            cfg_color_base <= 0; cfg_z_base <= 0;
            cfg_color_stride <= 0; cfg_z_stride <= 0;
            cfg_color <= 0; cfg_z0 <= 0; cfg_dx <= 0; cfg_dy <= 0;
            cfg_render_mode <= 0; cfg_written <= 0;
            done_valid <= 0;
            done_error <= 0;
            op <= 0; mode <= 0;
            row_src <= 0; row_dst <= 0; cur_src <= 0; cur_dst <= 0;
            rows_left <= 0; blocks_left <= 0; blocks_per_row <= 0;
            src_stride <= 0; dst_stride <= 0; pattern <= 0;
            dx <= 0; dy <= 0; row_z <= 0; cur_z <= 0;
            read_buffer <= 0; generated <= 0; write_mask <= 0;
            failed <= 0; tag_wr <= 0; tag_rd <= 0; tag_count <= 0;
            sp_color_row <= 0; sp_z_row <= 0; sp_color_cur <= 0; sp_z_cur <= 0;
            sp_color_stride <= 0; sp_z_stride <= 0;
            sp_width <= 0; sp_remaining <= 0; sp_rows <= 0;
            sp_row_initial <= 0; sp_cur_z <= 0; sp_dx <= 0; sp_dy <= 0;
            sp_color <= 0; sp_step <= 0; sp_z_data <= 0; sp_color_data <= 0;
            frag_index <= 0; frag_coverage <= 0; frag_colors <= 0; frag_depths <= 0;
            sp_z_mask <= 0; sp_color_mask <= 0;
        end else begin
            done_valid <= 1'b0;
            if (issue) begin
                tag_is_read[tag_wr] <= !req_write;
                tag_wr <= wr_next;
            end
            if (response) tag_rd <= rd_next;
            case ({issue,response})
                2'b10: tag_count <= tag_count + 1'b1;
                2'b01: tag_count <= tag_count - 1'b1;
                default: ;
            endcase
            if (response && rsp_error) failed <= 1'b1;
            if (read_response && !rsp_error) begin
                read_buffer <= rsp_rdata;
                if (op == OP_GEN) begin
                    // cmp_mask/gen_word use rsp_rdata combinationally.
                    generated <= gen_word;
                    write_mask <= cmp_mask;
                end else begin
                    write_mask <= 16'hffff;
                end
            end
            // A response error overrides normal state progression, so that
            // no further memory request is generated for this command.
            if (response && rsp_error && state != S_IDLE) begin
                state <= S_DRAIN;
            end else case (state)
                S_IDLE: if (cmd_valid) begin
                    if (!valid_command) begin
                        done_valid <= 1'b1;
                        done_error <= 1'b1;
                    end else if (cmd_op == OP_CONFIG) begin
                        if (cmd_mode[0]) begin
                            cfg_color_base <= p0;
                            cfg_z_base <= p1;
                        end
                        if (cmd_mode[1]) begin
                            cfg_color_stride <= p2;
                            cfg_z_stride <= p3;
                        end
                        if (cmd_mode[2]) cfg_color <= p4;
                        if (cmd_mode[3]) begin
                            cfg_z0 <= p5;
                            cfg_dx <= p6;
                            cfg_dy <= p7;
                        end
                        if (cmd_mode[4]) cfg_render_mode <= p8[7:0];
                        cfg_written <= cfg_written | cmd_mode[4:0];
                        done_valid <= 1'b1;
                        done_error <= 1'b0;
                    end else begin
                        op <= cmd_op;
                        mode <= ((cmd_op == OP_SPAN || cmd_op == OP_FRAGMENT) && compact_graphics) ?
                                {5'd0, cfg_render_mode} : cmd_mode;
                        failed <= 1'b0;
                        if (cmd_op == OP_FILL) begin
                            row_dst <= p0; cur_dst <= p0;
                            rows_left <= p2;
                            blocks_per_row <= p1 >> 4;
                            blocks_left <= p1 >> 4;
                            dst_stride <= p3;
                            pattern <= p4;
                        end else if (cmd_op == OP_COPY) begin
                            row_src <= p0; cur_src <= p0;
                            row_dst <= p1; cur_dst <= p1;
                            rows_left <= p3;
                            blocks_per_row <= p2 >> 4;
                            blocks_left <= p2 >> 4;
                            src_stride <= p4; dst_stride <= p5;
                        end else if (cmd_op == OP_SPAN || cmd_op == OP_FRAGMENT) begin
                            sp_color_row <= compact_graphics ? compact_color_address : p0;
                            sp_z_row <= compact_graphics ? compact_z_address : p1;
                            sp_color_cur <= compact_graphics ? compact_color_address : p0;
                            sp_z_cur <= compact_graphics ? compact_z_address : p1;
                            sp_width <= p2;
                            sp_remaining <= p2;
                            sp_rows <= p3;
                            sp_color_stride <= compact_graphics ? cfg_color_stride : p4;
                            sp_z_stride <= compact_graphics ? cfg_z_stride : p5;
                            sp_color <= compact_graphics ? effective_color : p6;
                            sp_row_initial <= compact_graphics ? effective_z0 : p7;
                            sp_cur_z <= compact_graphics ? effective_z0 : p7;
                            sp_dx <= compact_graphics ? effective_dx : p8;
                            sp_dy <= compact_graphics ? effective_dy : p9;
                            if (cmd_op == OP_FRAGMENT) begin
                                sp_width <= p2;
                                sp_remaining <= p2;
                                sp_rows <= 1;
                                sp_color_stride <= 0;
                                sp_z_stride <= 0;
                                frag_index <= 0;
                                frag_coverage <= p3[7:0];
                                frag_colors <= cmd_frag_colors;
                                frag_depths <= cmd_frag_z;
                            end
                        end else begin
                            row_dst <= p0; cur_dst <= p0;
                            rows_left <= p2;
                            blocks_per_row <= cmd_mode[3] ? (p1 >> 2) : (p1 >> 3);
                            blocks_left <= cmd_mode[3] ? (p1 >> 2) : (p1 >> 3);
                            dst_stride <= p3;
                            row_z <= p4; cur_z <= p4;
                            dx <= p5; dy <= p6;
                        end
                        state <= (cmd_op == OP_SPAN || cmd_op == OP_FRAGMENT) ? S_SP_PREP : S_PREP;
                    end
                end
                S_PREP: begin
                    if (needs_read) state <= S_READ_REQ;
                    else begin
                        write_mask <= 16'hffff;
                        if (op == OP_GEN) generated <= gen_word;
                        state <= S_WRITE_REQ;
                    end
                end
                S_READ_REQ: if (issue) state <= S_READ_WAIT;
                S_READ_WAIT: if (read_response) state <= S_WRITE_REQ;
                S_WRITE_REQ: if (write_mask == 0 || issue) state <= S_ADV;
                S_ADV: begin
                    if (blocks_left == 1) begin
                        if (rows_left == 1) begin
                            state <= S_DRAIN;
                        end else begin
                            rows_left <= rows_left - 1'b1;
                            blocks_left <= blocks_per_row;
                            row_src <= row_src + src_stride;
                            cur_src <= row_src + src_stride;
                            row_dst <= row_dst + dst_stride;
                            cur_dst <= row_dst + dst_stride;
                            row_z <= row_z + dy;
                            cur_z <= row_z + dy;
                            state <= S_PREP;
                        end
                    end else begin
                        blocks_left <= blocks_left - 1'b1;
                        cur_src <= cur_src + 32'd16;
                        cur_dst <= cur_dst + 32'd16;
                        cur_z <= cur_z + value_step;
                        state <= S_PREP;
                    end
                end
                // Compute one group with independent aligned word boundaries.
                // For conditional comparisons wait for Z read response first.
                S_SP_PREP: begin
                    sp_step <= sp_step_calc[2:0];
                    if (sp_cmp == 3'd0) begin
                        // Settle combinational masks on next clock.
                        state <= S_SP_READ_WAIT;
                    end else begin
                        state <= S_SP_READ_REQ;
                    end
                end
                S_SP_READ_REQ: if (issue) state <= S_SP_READ_WAIT;
                S_SP_READ_WAIT: begin
                    if (sp_cmp == 3'd0 || read_response) begin
                        sp_z_data <= sp_gen_z_word;
                        sp_color_data <= sp_gen_color_word;
                        sp_z_mask <= sp_gen_z_mask;
                        sp_color_mask <= sp_gen_color_mask;
                        state <= S_SP_Z_REQ;
                    end
                end
                S_SP_Z_REQ: begin
                    if (sp_z_mask == 0 || issue)
                        state <= S_SP_COLOR_REQ;
                end
                S_SP_COLOR_REQ: begin
                    if (sp_color_mask == 0 || issue)
                        state <= S_SP_SYNC;
                end
                // Completion of writes is required before reading next group:
                // successive 4-pixel groups can inhabit the same 128b Z word.
                // Without this barrier RMW can race pending Z writes.
                S_SP_SYNC: if (tag_count == 0) state <= S_SP_ADV;
                S_SP_ADV: begin
                    if (sp_remaining == {29'd0,sp_step}) begin
                        if (sp_rows == 1) begin
                            state <= S_DRAIN;
                        end else begin
                            sp_rows <= sp_rows - 1'b1;
                            sp_color_row <= sp_color_row + sp_color_stride;
                            sp_z_row <= sp_z_row + sp_z_stride;
                            sp_color_cur <= sp_color_row + sp_color_stride;
                            sp_z_cur <= sp_z_row + sp_z_stride;
                            sp_row_initial <= sp_row_initial + sp_dy;
                            sp_cur_z <= sp_row_initial + sp_dy;
                            sp_remaining <= sp_width;
                            state <= S_SP_PREP;
                        end
                    end else begin
                        sp_remaining <= sp_remaining - sp_step;
                        sp_color_cur <= sp_color_cur + (sp_color32 ? ({29'd0,sp_step} << 2) : ({29'd0,sp_step} << 1));
                        sp_z_cur <= sp_z_cur + (sp_z32 ? ({29'd0,sp_step} << 2) : ({29'd0,sp_step} << 1));
                        sp_cur_z <= sp_v;
                        if (op == OP_FRAGMENT) frag_index <= frag_index + sp_step;
                        state <= S_SP_PREP;
                    end
                end
                S_DRAIN: if (tag_count == 0) begin
                    done_valid <= 1'b1;
                    done_error <= failed;
                    state <= S_IDLE;
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
`default_nettype wire
