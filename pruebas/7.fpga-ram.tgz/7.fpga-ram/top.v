`default_nettype none

module top (
    input clk_25mhz,
    output [7:0] led,
    output wifi_gpio0,
    input ftdi_txd,
    output ftdi_rxd,

    output sdram_csn,
    output sdram_clk,
    output sdram_cke,
    output sdram_rasn,
    output sdram_casn,
    output sdram_wen,
    output [12:0] sdram_a,
    output [1:0] sdram_ba,
    output [1:0] sdram_dqm,
    inout [15:0] sdram_d
);

  // No PLL: the SDRAM controller and UART both run directly from the 25 MHz
  // board oscillator. This matches the ULX3S reference example the SDRAM
  // controller comes from (emard/ulx3s-misc), which drives sdram_clk with a
  // plain inverter instead of a phase-shifted PLL output. 120 MHz (used by
  // 5.fpga-monitor and 6.fpga-cpu) has no proven reference for this SDRAM
  // chip and was deliberately not attempted here.
  wire clk = clk_25mhz;
  assign sdram_clk = ~clk;  // 180 degrees, compensates board trace delay
  assign sdram_cke = 1'b1;

  assign wifi_gpio0 = 1'b1;

  // Power-on reset: a few cycles of reset after configuration, since there
  // is no PLL lock signal to key off in this design.
  reg [3:0] reset_counter = 4'hf;
  wire reset = reset_counter[3];
  always @(posedge clk) if (reset) reset_counter <= reset_counter - 1'b1;

  // UART interface: 25 MHz / 12 = 2,083,333 baud. Not 25 MHz / 8 (3.125
  // Mbaud): the ULX3S's FT231X is hard-capped at 3,000,000 baud, and going
  // over that gets silently clamped/rounded by the driver, desyncing the PC
  // and FPGA -- exactly the kind of thing that shows up as a total, 0-byte
  // timeout since even PING (which never touches the SDRAM) never decodes.
  localparam UART_DIVISOR = 12;

  wire [7:0] uart_rx_data;
  wire uart_rx_strobe;
  wire [7:0] uart_tx_data;
  wire uart_tx_strobe;
  wire uart_tx_ready;

  uart #(
      .DIVISOR(UART_DIVISOR)
  ) uart_i (
      .clk(clk),
      .reset(reset),
      .serial_txd(ftdi_rxd),
      .serial_rxd(ftdi_txd),
      .rxd(uart_rx_data),
      .rxd_strobe(uart_rx_strobe),
      .txd(uart_tx_data),
      .txd_strobe(uart_tx_strobe),
      .txd_ready(uart_tx_ready)
  );

  // Command monitor
  wire [7:0] last_command;
  wire monitor_busy;
  wire [31:0] mem_address;
  wire [7:0] mem_write_data;
  wire mem_write_enable;
  wire mem_read_enable;
  wire [7:0] mem_read_data;
  wire mem_ready;
  wire mem_error;

  monitor monitor_i (
      .clk(clk),
      .reset(reset),
      .rx_data(uart_rx_data),
      .rx_strobe(uart_rx_strobe),
      .tx_data(uart_tx_data),
      .tx_strobe(uart_tx_strobe),
      .tx_ready(uart_tx_ready),
      .mem_address(mem_address),
      .mem_write_data(mem_write_data),
      .mem_write_enable(mem_write_enable),
      .mem_read_enable(mem_read_enable),
      .mem_read_data(mem_read_data),
      .mem_ready(mem_ready),
      .mem_error(mem_error),
      .last_command(last_command),
      .busy(monitor_busy)
  );

  // Onboard SDR SDRAM, byte-addressed through the same contract memory.v
  // exposes in 5.fpga-monitor. C_ColBits=9 -> 32 MB, confirmed to match the
  // physical chip on this board.
  sdram_memory sdram_memory_i (
      .clk(clk),
      .reset(reset),
      .address(mem_address),
      .write_data(mem_write_data),
      .write_enable(mem_write_enable),
      .read_enable(mem_read_enable),
      .read_data(mem_read_data),
      .ready(mem_ready),
      .error(mem_error),
      .sdram_csn(sdram_csn),
      .sdram_wen(sdram_wen),
      .sdram_rasn(sdram_rasn),
      .sdram_casn(sdram_casn),
      .sdram_a(sdram_a),
      .sdram_ba(sdram_ba),
      .sdram_dqm(sdram_dqm),
      .sdram_d(sdram_d)
  );

  // Display the last command. LED 7 lights while a response is pending.
  assign led = {monitor_busy, last_command[6:0]};
endmodule

`default_nettype wire
