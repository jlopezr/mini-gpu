`timescale 1ns / 1ps
`default_nettype none

module monitor_tb;

  // Shrunk row/col/bank widths so the behavioral model's memory array stays
  // small and simulation is fast. The control paths (activate/precharge/
  // burst/DQM masking) are identical regardless of these widths.
  localparam C_COL_BITS = 4;
  localparam C_ROW_BITS = 4;
  localparam C_BANK_BITS = 2;
  localparam C_RFB = 4;

  reg clk = 1'b0;
  reg reset = 1'b1;
  reg [7:0] rx_data = 8'h00;
  reg rx_strobe = 1'b0;
  reg tx_ready = 1'b1;

  wire [7:0] tx_data;
  wire tx_strobe;
  wire [7:0] last_command;
  wire busy;
  wire [31:0] mem_address;
  wire [7:0] mem_write_data;
  wire mem_write_enable;
  wire mem_read_enable;
  wire [7:0] mem_read_data;
  wire mem_ready;
  wire mem_error;

  wire sdram_csn, sdram_wen, sdram_rasn, sdram_casn;
  wire [12:0] sdram_a;
  wire [1:0] sdram_ba;
  wire [1:0] sdram_dqm;
  wire [15:0] sdram_d;

  reg [7:0] received[0:31];
  integer received_count = 0;
  integer busy_cycles = 0;

  always #5 clk = ~clk;

  monitor dut (
      .clk(clk),
      .reset(reset),
      .rx_data(rx_data),
      .rx_strobe(rx_strobe),
      .tx_data(tx_data),
      .tx_strobe(tx_strobe),
      .tx_ready(tx_ready),
      .mem_address(mem_address),
      .mem_write_data(mem_write_data),
      .mem_write_enable(mem_write_enable),
      .mem_read_enable(mem_read_enable),
      .mem_read_data(mem_read_data),
      .mem_ready(mem_ready),
      .mem_error(mem_error),
      .last_command(last_command),
      .busy(busy)
  );

  sdram_memory #(
      .C_ColBits (C_COL_BITS),
      .C_RowBits (C_ROW_BITS),
      .C_BankBits(C_BANK_BITS),
      .C_RFB     (C_RFB)
  ) sdram_memory_i (
      .clk(clk),
      .reset(reset),
      .address(mem_address),
      .write_data(mem_write_data),
      .write_enable(mem_write_enable),
      .read_enable(mem_read_enable),
      .read_data(mem_read_data),
      .ready(mem_ready),
      .error(mem_error),
      .sdram_csn(sdram_csn),
      .sdram_wen(sdram_wen),
      .sdram_rasn(sdram_rasn),
      .sdram_casn(sdram_casn),
      .sdram_a(sdram_a),
      .sdram_ba(sdram_ba),
      .sdram_dqm(sdram_dqm),
      .sdram_d(sdram_d)
  );

  sdram_model #(
      .C_ColBits (C_COL_BITS),
      .C_RowBits (C_ROW_BITS),
      .C_BankBits(C_BANK_BITS)
  ) sdram_model_i (
      .sdram_clk(clk),
      .sdram_cke(1'b1),
      .sdram_csn(sdram_csn),
      .sdram_wen(sdram_wen),
      .sdram_rasn(sdram_rasn),
      .sdram_casn(sdram_casn),
      .sdram_a(sdram_a),
      .sdram_ba(sdram_ba),
      .sdram_dqm(sdram_dqm),
      .sdram_d(sdram_d)
  );

  // Minimal model of the uart_tx ready/strobe handshake.
  always @(posedge clk) begin
    if (reset) begin
      tx_ready <= 1'b1;
      busy_cycles <= 0;
    end else if (tx_strobe && tx_ready) begin
      received[received_count] <= tx_data;
      received_count <= received_count + 1;
      tx_ready <= 1'b0;
      busy_cycles <= 2;
    end else if (busy_cycles > 0) begin
      busy_cycles <= busy_cycles - 1;
      if (busy_cycles == 1) begin
        tx_ready <= 1'b1;
      end
    end
  end

  task send_command;
    input [7:0] command;
    begin
      @(negedge clk);
      rx_data = command;
      rx_strobe = 1'b1;
      @(negedge clk);
      rx_strobe = 1'b0;
      // A real UART byte takes thousands of clocks to arrive, so the SDRAM
      // transaction from the previous byte always finishes first. Here,
      // rx_strobe is injected directly, so this gap has to be wide enough
      // on its own to cover one full SDRAM transaction (activate/precharge,
      // CAS latency, burst-terminate, occasional refresh) before the next
      // byte lands -- otherwise a byte sent mid-transaction is silently
      // dropped (monitor.v isn't watching rx_strobe while it waits on
      // mem_ready), which stalls the block state machine forever.
      repeat (100) @(negedge clk);
    end
  endtask

  task send_address;
    input [31:0] address;
    begin
      send_command(address[31:24]);
      send_command(address[23:16]);
      send_command(address[15:8]);
      send_command(address[7:0]);
    end
  endtask

  integer n;

  initial begin
    #2000000;
    $display("TIMEOUT: stalled at received_count=%0d, state stuck (busy=%0d)", received_count, busy);
    $display("sdram_memory state=%0d mem_write_enable=%0d mem_read_enable=%0d mem_ready=%0d",
              sdram_memory_i.state, mem_write_enable, mem_read_enable, mem_ready);
    $display("sys_cmd=%0d sys_cmd_ack=%0d controller_STATE=%0d",
              sdram_memory_i.sys_cmd, sdram_memory_i.sys_cmd_ack, sdram_memory_i.sdram_16bit_i.STATE);
    $fatal(1, "watchdog timeout");
  end

  initial begin
    $dumpvars(0, monitor_tb);

    repeat (4) @(negedge clk);
    reset = 1'b0;

    // PING
    send_command(8'h01);
    wait (received_count == 1);
    if (received[0] !== 8'h81) $fatal(1, "PING response mismatch");

    // GET_VERSION
    wait (!busy && tx_ready);
    send_command(8'h02);
    wait (received_count == 4);
    if (received[1] !== 8'h82) $fatal(1, "VERSION response mismatch");
    if (received[2] !== 8'h01) $fatal(1, "VERSION major mismatch");
    if (received[3] !== 8'h00) $fatal(1, "VERSION minor mismatch");

    // Unknown command
    wait (!busy && tx_ready);
    send_command(8'h55);
    wait (received_count == 5);
    if (received[4] !== 8'hff) $fatal(1, "ERROR response mismatch");

    // WRITE_BYTE at address 0x000000AA (even -> low byte of its word)
    wait (!busy && tx_ready);
    send_command(8'h10);
    send_address(32'h000000AA);
    send_command(8'hAB);
    wait (received_count == 6);
    if (received[5] !== 8'h90) $fatal(1, "WRITE_BYTE(low) response mismatch");

    // WRITE_BYTE at address 0x000000AB (odd -> high byte of the SAME word)
    wait (!busy && tx_ready);
    send_command(8'h10);
    send_address(32'h000000AB);
    send_command(8'hCD);
    wait (received_count == 7);
    if (received[6] !== 8'h90) $fatal(1, "WRITE_BYTE(high) response mismatch");

    // READ_BYTE back both halves: this is the check that a single-byte
    // write does not spill into its sibling byte in the same 16-bit SDRAM
    // word (the DQM re-masking in sdram_16bit.v exists specifically for
    // this).
    wait (!busy && tx_ready);
    send_command(8'h11);
    send_address(32'h000000AA);
    wait (received_count == 9);
    if (received[7] !== 8'h91) $fatal(1, "READ_BYTE(low) response mismatch");
    if (received[8] !== 8'hAB)
      $fatal(1, "READ_BYTE(low) data mismatch: got %h expected AB (sibling byte corrupted it?)",
             received[8]);

    wait (!busy && tx_ready);
    send_command(8'h11);
    send_address(32'h000000AB);
    wait (received_count == 11);
    if (received[9] !== 8'h91) $fatal(1, "READ_BYTE(high) response mismatch");
    if (received[10] !== 8'hCD) $fatal(1, "READ_BYTE(high) data mismatch (sibling byte corrupted it?)");

    // WRITE_BLOCK of 5 bytes starting at an odd address, crossing two word
    // boundaries -- exercises repeated single-transaction column advances.
    wait (!busy && tx_ready);
    send_command(8'h20);
    send_address(32'h00000101);
    send_command(8'h00);
    send_command(8'h05);
    send_command(8'h11);
    send_command(8'h22);
    send_command(8'h33);
    send_command(8'h44);
    send_command(8'h55);
    wait (received_count == 12);
    if (received[11] !== 8'ha0) $fatal(1, "WRITE_BLOCK response mismatch");

    wait (!busy && tx_ready);
    send_command(8'h21);
    send_address(32'h00000101);
    send_command(8'h00);
    send_command(8'h05);
    wait (received_count == 18);
    if (received[12] !== 8'ha1) $fatal(1, "READ_BLOCK response mismatch");
    if (received[13] !== 8'h11) $fatal(1, "READ_BLOCK byte 0 mismatch");
    if (received[14] !== 8'h22) $fatal(1, "READ_BLOCK byte 1 mismatch");
    if (received[15] !== 8'h33) $fatal(1, "READ_BLOCK byte 2 mismatch");
    if (received[16] !== 8'h44) $fatal(1, "READ_BLOCK byte 3 mismatch");
    if (received[17] !== 8'h55) $fatal(1, "READ_BLOCK byte 4 mismatch");

    // Out-of-range WRITE_BYTE: with C_ColBits/C_RowBits/C_BankBits above,
    // capacity is 1 << (2+4+4+1) = 2048 bytes, so 0x00000800 is one past
    // the end.
    wait (!busy && tx_ready);
    send_command(8'h10);
    send_address(32'h00000800);
    send_command(8'h99);
    wait (received_count == 19);
    if (received[18] !== 8'hff) $fatal(1, "out-of-range WRITE_BYTE should error");

    $display("PASS: 7.fpga-ram monitor/sdram_memory responses are correct");
    $finish;
  end
endmodule

`default_nettype wire
