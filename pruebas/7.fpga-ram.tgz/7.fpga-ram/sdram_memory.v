`default_nettype none

/*
 * Adapter between the monitor's byte-wide ready/valid contract (the same one
 * memory.v exposes in 5.fpga-monitor) and sdram_16bit.v's word-wide command
 * interface. This lets top.v swap the internal 16 KiB block RAM for the
 * ULX3S onboard SDR SDRAM without touching monitor.v.
 *
 * Byte 0 of a 16-bit SDRAM word is its low byte (sdr_DATA[7:0]); byte 1 is
 * the high byte (sdr_DATA[15:8]), selected here through sdr_DQM.
 *
 * Every request (single byte or one step of a block) is driven to full
 * completion -- command accepted, data captured, controller back at idle --
 * before `ready` pulses, so the next request always finds the SDRAM
 * controller ready to accept it immediately.
 */
module sdram_memory #(
    parameter C_ColBits  = 9,  // 9 -> 16Mx16 (32 MB), 10 -> 32Mx16 (64 MB)
    parameter C_RowBits  = 13,
    parameter C_BankBits = 2,
    parameter C_RFB      = 7   // refresh bit, tuned for the clk actually driving this module
) (
    input clk,
    input reset,

    input  [31:0] address,
    input  [ 7:0] write_data,
    input         write_enable,
    input         read_enable,
    output reg [7:0] read_data,
    output reg       ready,
    output reg       error,

    output       sdram_csn,
    output       sdram_wen,
    output       sdram_rasn,
    output       sdram_casn,
    output [12:0] sdram_a,
    output [ 1:0] sdram_ba,
    output [ 1:0] sdram_dqm,
    inout  [15:0] sdram_d
);

  localparam WORD_BITS = C_RowBits + C_BankBits + C_ColBits;  // sys_ADDR width

  wire address_valid = (address[31:WORD_BITS+1] == 0);
  wire [WORD_BITS-1:0] word_address = address[WORD_BITS:1];
  wire byte_select = address[0];  // 0 = low byte, 1 = high byte

  localparam [2:0] S_IDLE = 3'd0;
  localparam [2:0] S_ISSUE = 3'd1;
  localparam [2:0] S_WAIT_READ = 3'd2;
  localparam [2:0] S_WAIT_IDLE = 3'd3;
  localparam [2:0] S_ERROR = 3'd4;

  reg [2:0] state;
  reg [1:0] cmd_reg;
  reg is_write;
  reg [WORD_BITS-1:0] word_address_reg;
  reg [7:0] write_data_reg;
  reg byte_select_reg;
  reg [7:0] read_byte;

  wire [1:0] sys_cmd = (state == S_ISSUE) ? cmd_reg : 2'b00;
  wire [15:0] sys_din = {write_data_reg, write_data_reg};
  wire [1:0] sys_dqm_in = byte_select_reg ? 2'b01 : 2'b10;
  wire [15:0] sys_dout;
  wire sys_rd_data_valid;
  wire sys_wr_data_valid;
  wire [1:0] sys_cmd_ack;

  wire [3:0] sdr_cs_we_ras_casn;
  assign {sdram_csn, sdram_wen, sdram_rasn, sdram_casn} = sdr_cs_we_ras_casn;

  sdram_16bit #(
      .C_ColBits (C_ColBits),
      .C_RowBits (C_RowBits),
      .C_BankBits(C_BankBits),
      .C_RFB     (C_RFB)
  ) sdram_16bit_i (
      .sys_CLK(clk),
      .sys_CMD(sys_cmd),
      .sys_ADDR(word_address_reg),
      .sys_DIN(sys_din),
      .sys_DQM_IN(sys_dqm_in),
      .sys_DOUT(sys_dout),
      .sys_rd_data_valid(sys_rd_data_valid),
      .sys_wr_data_valid(sys_wr_data_valid),
      .sys_cmd_ack(sys_cmd_ack),
      .sdr_n_CS_WE_RAS_CAS(sdr_cs_we_ras_casn),
      .sdr_BA(sdram_ba),
      .sdr_ADDR(sdram_a),
      .sdr_DATA(sdram_d),
      .sdr_DQM(sdram_dqm)
  );

  always @(posedge clk) begin
    ready <= 1'b0;

    if (reset) begin
      state <= S_IDLE;
      ready <= 1'b0;
      error <= 1'b0;
      read_data <= 8'h00;
      cmd_reg <= 2'b00;
      is_write <= 1'b0;
      word_address_reg <= {WORD_BITS{1'b0}};
      write_data_reg <= 8'h00;
      byte_select_reg <= 1'b0;
      read_byte <= 8'h00;
    end else begin
      case (state)
        S_IDLE: begin
          if (write_enable || read_enable) begin
            if (!address_valid) begin
              state <= S_ERROR;
            end else begin
              word_address_reg <= word_address;
              write_data_reg   <= write_data;
              byte_select_reg  <= byte_select;
              is_write <= write_enable;
              cmd_reg  <= write_enable ? 2'b01 : 2'b10;
              state    <= S_ISSUE;
            end
          end
        end

        S_ISSUE: begin
          if (sys_cmd_ack == cmd_reg) begin
            state <= is_write ? S_WAIT_IDLE : S_WAIT_READ;
          end
        end

        S_WAIT_READ: begin
          if (sys_rd_data_valid) begin
            read_byte <= byte_select_reg ? sys_dout[15:8] : sys_dout[7:0];
            state <= S_WAIT_IDLE;
          end
        end

        S_WAIT_IDLE: begin
          if (sys_cmd_ack == 2'b00) begin
            read_data <= read_byte;
            error <= 1'b0;
            ready <= 1'b1;
            state <= S_IDLE;
          end
        end

        S_ERROR: begin
          error <= 1'b1;
          ready <= 1'b1;
          state <= S_IDLE;
        end

        default: state <= S_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
