`default_nettype none
`timescale 1ns / 1ps

/*
 * Minimal behavioral SDR SDRAM model, for simulation only (never
 * synthesized -- top.v talks to the real chip). It implements the command
 * subset sdram_16bit.v actually issues: MODE REGISTER SET, PRECHARGE
 * (single bank or all banks via A10), ACTIVE, READ, WRITE, BURST TERMINATE
 * and AUTO REFRESH (accepted, no effect on stored data).
 *
 * Deliberately not timing-accurate against a real datasheet: it does not
 * enforce tRCD/tRP/tRC/tWR, so it cannot catch a controller that violates
 * those. What it does check is command sequencing and data integrity,
 * including that a single-beat write does not spill into the next column --
 * exactly the kind of full-page-burst-mode footgun sdram_16bit.v's fast
 * write path can hit if DQM is not re-masked immediately afterward.
 */
module sdram_model #(
    parameter C_ColBits  = 9,
    parameter C_RowBits  = 13,
    parameter C_BankBits = 2
) (
    input sdram_clk,
    input sdram_cke,
    input sdram_csn,
    input sdram_wen,
    input sdram_rasn,
    input sdram_casn,
    input [12:0] sdram_a,
    input [1:0] sdram_ba,
    input [1:0] sdram_dqm,
    inout [15:0] sdram_d
);

  localparam BANKS = 1 << C_BankBits;
  localparam WORD_BITS = C_BankBits + C_RowBits + C_ColBits;

  reg [15:0] mem[0:(1<<WORD_BITS)-1];

  wire cmd_active = !sdram_csn;
  wire is_mrs = cmd_active && !sdram_rasn && !sdram_casn && !sdram_wen;
  wire is_precharge = cmd_active && !sdram_rasn && sdram_casn && !sdram_wen;
  wire is_active_cmd = cmd_active && !sdram_rasn && sdram_casn && sdram_wen;
  wire is_write_cmd = cmd_active && sdram_rasn && !sdram_casn && !sdram_wen;
  wire is_read_cmd = cmd_active && sdram_rasn && !sdram_casn && sdram_wen;
  wire is_burst_term = cmd_active && sdram_rasn && sdram_casn && !sdram_wen;

  reg [12:0] mode_register;
  wire [2:0] cas_latency = mode_register[6:4];

  reg bank_active[0:BANKS-1];
  reg [C_RowBits-1:0] bank_row[0:BANKS-1];

  reg burst_active;
  reg burst_is_write;
  reg [C_BankBits-1:0] burst_bank;
  reg [C_ColBits-1:0] burst_col;

  // Read data pipeline, hardcoded for CAS latency 3 (the only value
  // sdram_16bit.v's mode-register-set constant ever programs here).
  // is_read_cmd is combinational (visible the same cycle as the READ
  // command); stage1 becomes visible 1 cycle later, stage2 2 cycles later,
  // and dout/dout_valid -- one more register past stage2 -- become visible
  // 3 cycles after the command, which is what CL=3 requires.
  reg stage1_valid, stage2_valid;
  reg [C_BankBits-1:0] stage1_bank, stage2_bank;
  reg [C_RowBits-1:0] stage1_row, stage2_row;
  reg [C_ColBits-1:0] stage1_col, stage2_col;

  reg [15:0] dout;
  reg dout_valid;
  assign sdram_d = dout_valid ? dout : 16'hzzzz;

  integer bank_i;

  initial begin
    for (bank_i = 0; bank_i < BANKS; bank_i = bank_i + 1) begin
      bank_active[bank_i] = 1'b0;
      bank_row[bank_i] = {C_RowBits{1'b0}};
    end
    burst_active = 1'b0;
    burst_is_write = 1'b0;
    stage1_valid = 1'b0;
    stage2_valid = 1'b0;
    dout_valid = 1'b0;
    mode_register = 13'b0;
  end

  always @(posedge sdram_clk) begin
    if (!sdram_cke) begin
      // Clock disabled: nothing changes.
    end else begin
      // Advance the read-latency pipeline every cycle (see field comment).
      stage2_valid <= stage1_valid;
      stage2_bank  <= stage1_bank;
      stage2_row   <= stage1_row;
      stage2_col   <= stage1_col;

      stage1_valid <= is_read_cmd;
      stage1_bank  <= sdram_ba;
      stage1_row   <= bank_row[sdram_ba];
      stage1_col   <= sdram_a[C_ColBits-1:0];

      dout_valid <= stage2_valid;
      if (stage2_valid) dout <= mem[{stage2_bank, stage2_row, stage2_col}];

      // A full-page write burst captures the bus every cycle it is active,
      // regardless of the command bus (NOP is a normal burst-continuation
      // cycle), masked per-byte by DQM. This is what actually exercises
      // whether the controller re-masks DQM outside a real write beat.
      if (burst_active && burst_is_write) begin
        if (!sdram_dqm[0])
          mem[{burst_bank, bank_row[burst_bank], burst_col}][7:0] <= sdram_d[7:0];
        if (!sdram_dqm[1])
          mem[{burst_bank, bank_row[burst_bank], burst_col}][15:8] <= sdram_d[15:8];
        burst_col <= burst_col + 1'b1;
      end

      if (is_mrs) begin
        mode_register <= sdram_a;
      end else if (is_precharge) begin
        if (sdram_a[10]) begin
          for (bank_i = 0; bank_i < BANKS; bank_i = bank_i + 1)
            bank_active[bank_i] <= 1'b0;
        end else begin
          bank_active[sdram_ba] <= 1'b0;
        end
        burst_active <= 1'b0;
      end else if (is_active_cmd) begin
        bank_active[sdram_ba] <= 1'b1;
        bank_row[sdram_ba] <= sdram_a[C_RowBits-1:0];
        burst_active <= 1'b0;
      end else if (is_write_cmd) begin
        burst_active <= 1'b1;
        burst_is_write <= 1'b1;
        burst_bank <= sdram_ba;
        burst_col <= sdram_a[C_ColBits-1:0];
        if (!sdram_dqm[0])
          mem[{sdram_ba, bank_row[sdram_ba], sdram_a[C_ColBits-1:0]}][7:0] <= sdram_d[7:0];
        if (!sdram_dqm[1])
          mem[{sdram_ba, bank_row[sdram_ba], sdram_a[C_ColBits-1:0]}][15:8] <= sdram_d[15:8];
        burst_col <= sdram_a[C_ColBits-1:0] + 1'b1;
      end else if (is_read_cmd) begin
        burst_active <= 1'b0;
      end else if (is_burst_term) begin
        burst_active <= 1'b0;
      end
    end
  end
endmodule

`default_nettype wire
